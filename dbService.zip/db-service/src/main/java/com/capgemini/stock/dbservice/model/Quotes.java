package com.capgemini.stock.dbservice.model;

public class Quotes {

}
