package com.capgemini.stock.dbservice.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.stock.dbservice.model.Quote;

public interface QuotesRepository extends MongoRepository<Quote,Integer> {

	List<Quote> findByUserName(String username);

}
